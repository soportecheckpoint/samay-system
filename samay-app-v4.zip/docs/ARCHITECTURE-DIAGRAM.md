# Diagrama de Arquitectura del Sistema

## 🏗️ Arquitectura General

```
┌─────────────────────────────────────────────────────────────────────┐
│                         SERVIDOR CENTRAL                             │
│                      Node.js + Socket.io                             │
│                    http://192.168.1.10:3001                          │
│                                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │   Routes     │  │   Socket     │  │   Services   │              │
│  │   /connect   │  │   Handlers   │  │   Timer      │              │
│  │   /dispatch  │  │              │  │   Arduino    │              │
│  │   /heartbeat │  │              │  │              │              │
│  └──────────────┘  └──────────────┘  └──────────────┘              │
│                                                                       │
│  ┌─────────────────────────────────────────────────────┐            │
│  │              Estado Global (gameState)              │            │
│  │  - arduinos: { buttons, connections, nfc }          │            │
│  │  - session: { timer, teamName, status }             │            │
│  │  - games: { MODULE_BUTTONS, MODULE_TABLET, ... }    │            │
│  │  - clients: { socket connections }                  │            │
│  └─────────────────────────────────────────────────────┘            │
└─────────────────────────────────────────────────────────────────────┘
                             │
                             │ WebSocket (Socket.io)
                             │ HTTP REST
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
┌──────────────┐     ┌──────────────┐    ┌──────────────┐
│   HTTP POST  │     │   HTTP POST  │    │   HTTP POST  │
│   (Arduino)  │     │   (Arduino)  │    │   (Arduino)  │
└──────────────┘     └──────────────┘    └──────────────┘
        │                    │                    │
        ▼                    ▼                    ▼
┌──────────────┐     ┌──────────────┐    ┌──────────────┐
│   ARDUINO    │     │   ARDUINO    │    │   ARDUINO    │
│   Botones    │     │  Conexiones  │    │   NFC/RFID   │
│   (buttons)  │     │(connections) │    │    (nfc)     │
│              │     │              │    │              │
│  8 Botones   │     │  12-16 Pines │    │  5 Lectores  │
│  Físicos     │     │  + Cables    │    │  RC522       │
└──────────────┘     └──────────────┘    └──────────────┘
        ▲                    ▲                    ▲
        │                    │                    │
        │ Servidor HTTP      │ Servidor HTTP      │ Servidor HTTP
        │ :8080/control      │ :8080/control      │ :8080/control
        │                    │                    │
        └────────────────────┴────────────────────┘
                             │
                      Comandos desde
                        Servidor
                             │
        ┌────────────────────┴────────────────────┐
        │                                         │
        ▼                                         ▼
┌──────────────────┐                    ┌──────────────────┐
│  WebSocket       │                    │  WebSocket       │
│  Clientes        │                    │  Clientes        │
│  (Apps React)    │                    │  (Apps React)    │
└──────────────────┘                    └──────────────────┘
        │                                         │
        │                                         │
┌───────┴────────┬──────────┬──────────┬─────────┴────────┐
│                │          │          │                  │
▼                ▼          ▼          ▼                  ▼
┌──────────┐ ┌─────────┐ ┌─────────┐ ┌──────────┐ ┌──────────┐
│  Admin   │ │ Buttons │ │  Main   │ │  Tablet  │ │  Totem   │
│   iPad   │ │  Game   │ │ Screen  │ │ Feedback │ │ Táctil   │
└──────────┘ └─────────┘ └─────────┘ └──────────┘ └──────────┘
```

---

## 🔄 Flujo de Comunicación Completo

### 1. Inicialización del Sistema

```
┌──────────┐                  ┌──────────┐
│ Arduino  │                  │ Servidor │
└────┬─────┘                  └────┬─────┘
     │                             │
     │  POST /connect              │
     │  { id, ip, port }           │
     │─────────────────────────────>
     │                             │
     │  200 OK                     │
     │  { status: registered }     │
     │<─────────────────────────────
     │                             │
     │  (Cada 15 segundos)         │
     │  POST /heartbeat            │
     │─────────────────────────────>
     │                             │
     │  200 OK                     │
     │<─────────────────────────────
     │                             │
```

```
┌──────────┐                  ┌──────────┐
│ App React│                  │ Servidor │
└────┬─────┘                  └────┬─────┘
     │                             │
     │  WebSocket connect          │
     │─────────────────────────────>
     │                             │
     │  emit('register')           │
     │  { appType, sessionId }     │
     │─────────────────────────────>
     │                             │
     │  emit('state:update')       │
     │  { session, tablet }        │
     │<─────────────────────────────
     │                             │
```

---

### 2. Juego de Botones - Flujo Completo

```
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│ Buttons  │  │ Servidor │  │ Arduino  │  │   Main   │  │  Admin   │
│   App    │  │          │  │          │  │  Screen  │  │   iPad   │
└────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘
     │             │             │             │             │
     │ User ingresa│             │             │             │
     │ código 1606 │             │             │             │
     │             │             │             │             │
     │emit(buttons:│             │             │             │
     │code-entered)│             │             │             │
     │────────────>│             │             │             │
     │             │             │             │             │
     │             │ POST        │             │             │
     │             │/control     │             │             │
     │             │{cmd:start}  │             │             │
     │             │────────────>│             │             │
     │             │             │             │             │
     │             │ 200 OK      │             │             │
     │             │<────────────│             │             │
     │             │             │             │             │
     │on(buttons:  │             │ Arduino     │             │
     │game-started)│             │ inicia      │             │
     │<────────────│             │ juego       │             │
     │             │             │             │             │
     │             │             │ User        │             │
     │             │             │ presiona    │             │
     │             │             │ botón 1     │             │
     │             │             │             │             │
     │             │ POST        │             │             │
     │             │ /dispatch   │             │             │
     │             │ {event:     │             │             │
     │             │  buttons:   │             │             │
     │             │  state-     │             │             │
     │             │  changed}   │             │             │
     │             │<────────────│             │             │
     │             │             │             │             │
     │             │ WebSocket   │             │             │
     │             │ broadcast   │             │             │
     │             │ a todos     │             │             │
     │             │             │             │             │
     │on(buttons:  │             │             │on(buttons:  │on(buttons:
     │state-changed│             │             │state-changed│state-changed
     │<────────────│─────────────│─────────────│────────────>│───────────>
     │             │             │             │             │
     │ UI actualiza│             │             │ UI actualiza│ UI actualiza
     │             │             │             │             │
     │             │             │ User        │             │
     │             │             │ completa    │             │
     │             │             │ secuencia   │             │
     │             │             │             │             │
     │             │ POST        │             │             │
     │             │ /dispatch   │             │             │
     │             │ {completed: │             │             │
     │             │  true,      │             │             │
     │             │  code:1234} │             │             │
     │             │<────────────│             │             │
     │             │             │             │             │
     │on(module:   │             │             │on(module:   │on(module:
     │completed)   │             │             │completed)   │completed)
     │<────────────│─────────────│─────────────│────────────>│───────────>
     │             │             │             │             │
     │ Mostrar     │             │             │ Mostrar     │ Update
     │ código 1234 │             │             │ código 1234 │ status
     │             │             │             │             │
```

---

### 3. Tablero de Conexiones → Totem Táctil

```
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│ Arduino  │  │ Servidor │  │  Totem   │  │  Admin   │
│Conexiones│  │          │  │ Táctil   │  │   iPad   │
└────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘
     │             │             │             │
     │ User        │             │             │
     │ conecta     │             │             │
     │ cables      │             │             │
     │             │             │             │
     │ POST        │             │             │
     │ /dispatch   │             │             │
     │ {event:     │             │             │
     │  connections│             │             │
     │  :state-    │             │             │
     │  changed}   │             │             │
     │────────────>│             │             │
     │             │             │             │
     │             │ WebSocket   │             │
     │             │ broadcast   │             │
     │             │             │             │
     │             │on(connections            │
     │             │:state-changed             │
     │             │────────────>│             │
     │             │             │             │
     │             │             │ Totem       │
     │             │             │ actualiza   │
     │             │             │ estado      │
     │             │             │             │
     │ Todas las   │             │             │
     │ conexiones  │             │             │
     │ correctas   │             │             │
     │             │             │             │
     │ POST        │             │             │
     │ /dispatch   │             │             │
     │ {completed: │             │             │
     │  true,      │             │             │
     │  code:7482} │             │             │
     │────────────>│             │             │
     │             │             │             │
     │             │on(connections            │
     │             │:state-changed             │
     │             │────────────>│             │
     │             │             │             │
     │             │             │ Totem activa│
     │             │             │ fase de     │
     │             │             │ Match       │
     │             │             │ (muestra    │
     │             │             │ código 7482)│
     │             │             │             │
```

---

### 4. NFC → Totem Táctil (6ta Insignia)

```
┌──────────┐  ┌──────────┐  ┌──────────┐
│ Arduino  │  │ Servidor │  │  Totem   │
│   NFC    │  │          │  │ Táctil   │
└────┬─────┘  └────┬─────┘  └────┬─────┘
     │             │             │
     │ User coloca │             │
     │ insignias   │             │
     │ NFC         │             │
     │             │             │
     │ POST        │             │
     │ /dispatch   │             │
     │ {event:     │             │
     │  nfc:state- │             │
     │  changed,   │             │
     │  detected:3}│             │
     │────────────>│             │
     │             │             │
     │             │on(nfc:      │
     │             │state-changed│
     │             │────────────>│
     │             │             │
     │             │             │ Totem       │
     │             │             │ actualiza   │
     │             │             │ contador    │
     │             │             │ insignias   │
     │             │             │             │
     │ Todas las 5 │             │             │
     │ insignias   │             │             │
     │ detectadas  │             │             │
     │             │             │             │
     │ POST        │             │             │
     │ /dispatch   │             │             │
     │ {completed: │             │             │
     │  true,      │             │             │
     │  badges:5}  │             │             │
     │────────────>│             │             │
     │             │             │             │
     │             │on(nfc:      │             │
     │             │state-changed│             │
     │             │────────────>│             │
     │             │             │             │
     │             │             │ Totem muestra
     │             │             │ 6ta insignia│
     │             │             │ virtual     │
     │             │             │             │
```

---

### 5. Tablet → Main Screen (Proyección)

```
┌──────────┐  ┌──────────┐  ┌──────────┐
│  Tablet  │  │ Servidor │  │   Main   │
│ Feedback │  │          │  │  Screen  │
└────┬─────┘  └────┬─────┘  └────┬─────┘
     │             │             │
     │ User en     │             │
     │ paso de     │             │
     │ feedback    │             │
     │             │             │
     │emit(tablet: │             │
     │mirror)      │             │
     │{screen:     │             │
     │ feedback_   │             │
     │ form,       │             │
     │ content:{}} │             │
     │────────────>│             │
     │             │             │
     │             │on(tablet:   │
     │             │mirror)      │
     │             │────────────>│
     │             │             │
     │             │             │ Main Screen│
     │             │             │ proyecta   │
     │             │             │ contenido  │
     │             │             │ en tiempo  │
     │             │             │ real       │
     │             │             │             │
     │ User escribe│             │             │
     │ feedback    │             │             │
     │             │             │             │
     │emit(tablet: │             │             │
     │mirror)      │             │             │
     │{content:    │             │             │
     │ {feedback   │             │             │
     │ Text:"..."}}│             │             │
     │────────────>│             │             │
     │             │             │             │
     │             │on(tablet:   │             │
     │             │mirror)      │             │
     │             │────────────>│             │
     │             │             │             │
     │             │             │ Actualiza   │
     │             │             │ texto en    │
     │             │             │ proyección  │
     │             │             │             │
```

---

### 6. Admin iPad - Control Total

```
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│  Admin   │  │ Servidor │  │ Arduino  │  │  Apps    │
│   iPad   │  │          │  │          │  │  React   │
└────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘
     │             │             │             │
     │emit(admin:  │             │             │
     │get-state)   │             │             │
     │────────────>│             │             │
     │             │             │             │
     │on(admin:    │             │             │
     │state-update)│             │             │
     │<────────────│             │             │
     │             │             │             │
     │ Mostrar     │             │             │
     │ estado de   │             │             │
     │ todos los   │             │             │
     │ módulos     │             │             │
     │             │             │             │
     │emit(admin:  │             │             │
     │command)     │             │             │
     │{cmd:'reset- │             │             │
     │ module',    │             │             │
     │ data:{      │             │             │
     │ module:     │             │             │
     │ 'buttons'}} │             │             │
     │────────────>│             │             │
     │             │             │             │
     │             │ POST        │             │
     │             │/control     │             │
     │             │{cmd:reset}  │             │
     │             │────────────>│             │
     │             │             │             │
     │             │             │ Arduino     │
     │             │             │ resetea     │
     │             │             │             │
     │             │on(buttons:  │             │
     │             │reset)       │             │
     │             │─────────────│────────────>│
     │             │             │             │
     │             │             │             │ Apps
     │             │             │             │ resetean
     │             │             │             │ estado
     │             │             │             │
```

---

## 📊 Tabla de Comunicación

| Origen | Destino | Protocolo | Endpoint/Event | Propósito |
|--------|---------|-----------|----------------|-----------|
| Arduino | Servidor | HTTP POST | `/connect` | Registro inicial |
| Arduino | Servidor | HTTP POST | `/heartbeat` | Señal de vida |
| Arduino | Servidor | HTTP POST | `/dispatch` | Enviar eventos |
| Servidor | Arduino | HTTP POST | `:8080/control` | Enviar comandos |
| App React | Servidor | WebSocket | `register` | Registro de cliente |
| App React | Servidor | WebSocket | eventos varios | Acciones de usuario |
| Servidor | App React | WebSocket | eventos varios | Actualizaciones de estado |
| Servidor | Todas las Apps | WebSocket | broadcast | Distribución de eventos |

---

## 🔑 IDs y Nombres Clave

### Arduino IDs
- `"buttons"` - Arduino de botones
- `"connections"` o `"tablero-conexiones"` - Arduino de conexiones
- `"nfc"`, `"rfid"` o `"tablero-nfc"` - Arduino NFC/RFID

### Module IDs (Estado del Servidor)
- `"MODULE_BUTTONS"` - Módulo de botones
- `"MODULE_TABLET"` - Módulo de tablet
- `"MODULE_TOTEM"` - Módulo de totem
- `"MODULE_CONNECTIONS"` - Módulo de conexiones (opcional)
- `"MODULE_RFID"` o `"MODULE_NFC"` - Módulo NFC (opcional)

### App Types
- `"admin-ipad"` - iPad administrador
- `"buttons-game"` - Juego de botones
- `"main-screen"` - Pantalla principal
- `"tablet-feedback"` - Tablet de feedback
- `"totem-tactil"` - Totem táctil

---

## 📝 Notas Importantes

1. **Todos los Arduinos** deben estar conectados a la misma red que el servidor
2. **El servidor** debe tener IP fija o un hostname conocido
3. **Los heartbeats** son críticos - el servidor marca Arduinos como desconectados después de 30s sin heartbeat
4. **Los eventos** son broadcast a todas las apps conectadas - cada app filtra lo que necesita
5. **El Admin iPad** es la única interfaz con control total del sistema
6. **La Main Screen** solo recibe eventos, no envía ninguno
7. **El Totem** puede configurarse para escuchar diferentes eventos mediante variables de entorno
