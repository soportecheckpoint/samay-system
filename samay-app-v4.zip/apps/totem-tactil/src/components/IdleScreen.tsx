import View from '../view-manager/View';

export function IdleScreen() {
  return (
    <View viewId="idle">
      <div className="w-full h-full bg-black" />
    </View>
  );
}
