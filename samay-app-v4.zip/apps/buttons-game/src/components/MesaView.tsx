import React from 'react';
import View from '../view-manager/View';
import { useGameStore } from '../store';

export const MesaView: React.FC = () => {
  const { buttons } = useGameStore();

  // Dividir los botones en dos filas: 5 arriba (1-5) y 5 abajo (6-10)
  const topButtons = buttons.slice(0, 5);
  const bottomButtons = buttons.slice(5, 10);

  return (
    <View viewId="mesa">
      <div 
        className="w-full h-full flex items-center justify-center"
        style={{
          backgroundImage: 'url(/bttn_bg_mesa.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      >
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Imagen de la mesa */}
          <img 
            src="/mesa.png" 
            alt="Mesa" 
            className="absolute max-w-[80%] max-h-[80%] object-contain"
            style={{
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)'
            }}
          />
          
          {/* Contenedor de botones */}
          <div className="relative z-10 flex flex-col items-center justify-center gap-16 mr-4">
            {/* Fila superior - 5 botones */}
            <div className="flex gap-[9vw]">
              {topButtons.map((button) => (
                <div
                  key={button.id}
                  className="w-16 h-16 rounded-full border-4 border-white/40 transition-all duration-300"
                  style={{
                    backgroundColor: button.pressed ? '#ef4444' : '#000000',
                    boxShadow: button.pressed 
                      ? '0 0 30px rgba(239, 68, 68, 0.8), 0 0 60px rgba(239, 68, 68, 0.4)' 
                      : '0 0 10px rgba(0, 0, 0, 0.5)'
                  }}
                />
              ))}
            </div>

            {/* Fila inferior - 5 botones */}
            <div className="flex gap-[9vw]">
              {bottomButtons.map((button) => (
                <div
                  key={button.id}
                  className="w-16 h-16 rounded-full border-4 border-white/40 transition-all duration-300"
                  style={{
                    backgroundColor: button.pressed ? '#ef4444' : '#000000',
                    boxShadow: button.pressed 
                      ? '0 0 30px rgba(239, 68, 68, 0.8), 0 0 60px rgba(239, 68, 68, 0.4)' 
                      : '0 0 10px rgba(0, 0, 0, 0.5)'
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </View>
  );
};
