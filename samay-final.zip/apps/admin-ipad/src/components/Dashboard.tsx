import { DashboardV2 } from './DashboardV2';

export function Dashboard() {
  return <DashboardV2 />;
}